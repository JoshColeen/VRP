function drawRoute(routes, palette) {
  var graph = d3.select('svg');

  var drawLine = d3.svg.line()
        .x(d => d.x)
        .y(d => d.y)
        .interpolate('linear');

  routes.forEach(function(route, index) {
    var wrappedRoute = [App.warehouse].concat(route, App.warehouse);
    var lines = graph.append('path')
          .attr('d', drawLine(wrappedRoute))
          .attr('stroke', palette[index])
          .attr('stroke-width', 2)
          .attr('fill', 'none')
          .on('mouseover', function() {
            d3.select(this).attr('stroke-width', 5)
              .on('mouseout', function() {
                d3.select(this).attr('stroke-width', 2);
              });
          });
  });

  return routes;
}

function clearRoute() {
  d3.select('svg')
    .selectAll('path').remove();
}

function drawPoints(points) {
  d3.select('svg')
    .selectAll('circle')
    .data(points).enter()
    .append('circle')
    .attr('cx', d => d.x)
    .attr('cy', d => d.y)
    .attr('r', '0.2em')
    .on('mouseover', function() {
      d3.select(this).attr('r', '0.4em')
        .on('mouseout', function() {
          d3.select(this).attr('r', '0.2em');
        });
    });
}

function drawWarehouse(pos) {
  d3.select('svg').selectAll('rect')
    .data([pos]).enter()
    .append('rect')
    .attr('width', '14px')
    .attr('height', '14px')
    .attr('x', d => d.x - 7)
    .attr('y', d => d.y - 7)
    .attr('fill', '#CA5128');
}

function clearPoints() {
  App.points = [];
  d3.select('svg')
    .selectAll('circle')
    .remove();
}

