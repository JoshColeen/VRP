var Test = {
  globalNeighborhood: function(count) {
    count = count || 10;
    return Array(count).every(function(_) {
      var initial = initialSolution(App.points);
      return globalNeighborhood(initial).every(function(solution) {
        var length = solution.reduce((a, b) => a + b.length, 0);
        if (length === App.points.length) {
          return true;
        }
        console.error(`Expected: ${App.points.length} | Actual: ${length}`);
        return false;
      });
    });
  },
  samplePoints: [
  {"x": 200, "y": 211},
  {"x": 365, "y": 150},
  {"x": 326, "y": 327},
  {"x": 441, "y": 333},
  {"x": 513, "y": 336},
  {"x": 638, "y": 239},
  {"x": 655, "y": 207},
  {"x": 546, "y": 168},
  {"x": 439, "y": 122},
  {"x": 285, "y": 42},
  {"x": 213, "y": 63},
  {"x": 183, "y": 124},
  {"x": 133, "y": 220},
  {"x": 128, "y": 299},
  {"x": 215, "y": 321},
  {"x": 251, "y": 305},
  {"x": 253, "y": 230},
  {"x": 262, "y": 224},
  {"x": 1032, "y": 346},
  {"x": 1066, "y": 292},
  {"x": 1092, "y": 273},
  {"x": 1151, "y": 314},
  {"x": 1165, "y": 394},
  {"x": 1140, "y": 408},
  {"x": 1102, "y": 408},
  {"x": 1076, "y": 357},
  {"x": 1058, "y": 328},
  {"x": 1013, "y": 316},
  {"x": 973, "y": 338},
  {"x": 933, "y": 410},
  {"x": 956, "y": 441},
  {"x": 1012, "y": 440},
  {"x": 1086, "y": 450},
  {"x": 1111, "y": 469},
  {"x": 1228, "y": 298},
  {"x": 1211, "y": 276},
  {"x": 1162, "y": 249},
  {"x": 1119, "y": 213},
  {"x": 1107, "y": 184},
  {"x": 457, "y": 572},
  {"x": 418, "y": 580},
  {"x": 332, "y": 589},
  {"x": 263, "y": 580},
  {"x": 255, "y": 546},
  {"x": 213, "y": 558},
  {"x": 193, "y": 583},
  {"x": 217, "y": 495},
  {"x": 358, "y": 470},
  {"x": 491, "y": 522}
  ]
}; 
