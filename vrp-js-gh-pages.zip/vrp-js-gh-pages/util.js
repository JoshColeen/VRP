function onReady(cb) {
  if (document.readyState !== 'loading') {
    cb();
  }
  else {
    document.addEventListener('DOMContentLoaded', cb);
  }
}

onReady(function() {
  if (window.localStorage.VRP_JS_SKIP_WELCOME !== 'true') {
    document.querySelector('body')
      .classList.add('has-dialog', 'has-welcome');
  }
});

function toggleShowModal(value) {
  window.localStorage.VRP_JS_SKIP_WELCOME = value;
}

function showSettings() {
  document.querySelector('body')
    .classList.add('has-dialog', 'has-settings');
}

function saveSettings(e) {
  e.preventDefault();

  const find = selector => parseInt(e.target.querySelector(selector).value);

  App.fleetSize = find('#fleet_size');
  App.dRunner = find('#d_runner');
  App.dRoot = find('#d_root');
  App.globalIter = find('#global_iter');
  App.localIter = find('#local_iter');
  App.nPlants = find('#n_plants');
  App.neighborhoodSize = find('#neighborhood');

  closeModal();
}

function closeModal() {
  document.querySelector('body')
    .classList.remove('has-dialog', 'has-welcome', 'has-settings');
}

function toggleSpinner(show) {
  var body = document.getElementsByTagName('body')[0];
  return show ?
    body.classList.add('loading') :
    body.classList.remove('loading');
}

function reportResults(fn, costFn, resultFn) {
  const beginning = new Date(),
        result = fn(),
        end = new Date(),
        running = end - beginning;

  localforage.getItem('VRP_JS_BENCHMARKS')
    .then(function(value) {
      if (!value || !value.length) {
        value = [];
      }
      localforage.setItem('VRP_JS_BENCHMARKS', value.concat({
        params: App,
        cost: costFn(result),
        time: running
      }));
    });

  console.log(`Running time: ${running}ms`);
  console.log(`Final cost: ${costFn(result)}`);

  return resultFn(result);
}

var params = {
  fleetSize: 5,
  dRunner: 5,
  dRoot: 5,
  globalIter: 5,
  localIter: 30,
  nPlants: 100,
  neighborhoodSize: 100,
  warehouse: { x: 400, y: 500 }
};

