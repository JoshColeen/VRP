/* globals onReady _ clearRoute drawRoute drawPoints d3 */
// TODO: this whole file needs refactoring to be more functional

var App = _.extend({ }, {
  requests: {
    pickups: [ ],
    deliveries: [ ]
  },
  points: [ ]
}, params);

App.palette = Please.make_color({
  colors_returned: App.fleetSize
});

onReady(function() {
  // This is for testing only!
  drawWarehouse(App.warehouse);
  drawPoints(App.points = Test.samplePoints);
  d3.select('svg').on('click', function() {
    App.points.push(point(d3.mouse(this)));

    drawPoints(App.points);
  });

  d3.select('#plot-route').on('click', function() {
    clearRoute();

    const calculate = () => findRoute(App.points, App.fleetSize);
    drawRoute(reportResults(calculate, res => res.cost, res => res.solution),
              App.palette);
  });

  d3.select('#clear-route').on('click', function() {
    clearRoute();
    clearPoints();
  });
});

function point(coords) { return { x: coords[0], y: coords[1] }; }

function initialPopulation(points) {
  return _.map(Array(App.nPlants), _ => initialSolution(points));
}

function initialSolution(points) {
  var chunked = _.chunk(points, Math.ceil(points.length/App.fleetSize));
  return chunked.concat(_.fill(Array(App.fleetSize - chunked.length), []));
}

// TODO: best solution throws a child in the same position as itself
function globalSearch(population) {
  return population.map(sol => bestSolution(globalNeighborhood(sol)).solution);
}

// needs more testing! esp. for small values of solution.length (cf test.js)
// this should generate a few solutions, so globalSearch returns the best
function globalNeighborhood(solution) {
  var improve = function(route, index) {
    var clone = _.clone(solution, true);
    return _(route).shuffle().thru(value => {
      var toRemove = Math.floor(Math.random() * App.dRunner);
      clone[index] = _.drop(value, toRemove);
      return _.take(value, toRemove);
    }).map(function(point) {
      _.sample(clone).push(point);
      return clone;
    }).value();
  };

  return solution.map(improve).reduce((x, y) => x.concat(y), []);
}

// TODO: Run more of these, because solutions are pretty bad!
function localNeighborhood(solution) {
  var switchRoute = function(route) {
    var clone = _.clone(route, true),
        toRemove = Math.min(clone.length,
                            Math.floor(App.dRoot * Math.random())),
        removed = pick(clone, toRemove);
    return clone.concat(removed);
  };
  var improve = solution => solution.map(switchRoute);

  return _.map(Array(App.neighborhoodSize), _ => improve(solution));
}

function localSearch(solution) {
  return bestSolution(localNeighborhood(solution));
}

function pick(list, size) {
  var randomIndex = list => Math.floor(Math.random() * list.length);
  var removed = [];
  _.each(Array(size), function() {
    removed.push(list.splice(randomIndex(list), 1).pop());
  });

  return removed;
}

/* - each plant in the population throws a runner in a random direction
 * - the fittest plant throws a runner in the same location as itself
 * - if that move generated an overall improvement, do it again
 * - otherwise, start local search on fittest plant
 */
function iterate(population, cost) {
  var iter = 0,
      bestCost = cost,
      bestPopulation = population;

  while (iter < App.localIter) {
    var current = globalSearch(population),
        currentBest = bestSolution(current),
        currentCost = currentBest.cost;

    if (currentCost < bestCost) {
      bestCost = currentCost;
      population = current;
      iter = 0;
    }
    else {
      ++iter;
    }
  }

  iter = 0;
  var best = currentBest;
  while (iter < App.localIter) {
    var currentSolution = localSearch(best.solution);
    if (currentSolution.cost < best.cost) {
      bestCost = currentSolution.cost;
      best = currentSolution;
      iter = 0;
    }
    else {
      ++iter;
    }
  }
  return best;
}

function reportResult(result) {
  console.log(`Found solution with cost ${result.cost}:`);
  console.log(result.solution);
  return result.solution;
}

function solutionCost(solution) {
  // change this for non-euclidean cost functions
  var distanceFn = function(p1, p2) {
    if (!(p1 && p2)) { return 0; }
    var square = x => x * x;
    return Math.sqrt(square(p2.x - p1.x) + square(p2.y - p1.y));
  };
  var routeCost = function(route) {
    if (!route) return 0;
    var acc = distanceFn(App.warehouse, route[0]);

    route.slice(1).forEach(function(_, index) {
      acc += distanceFn(route[index - 1], route[index]);
    });

    return acc + distanceFn(_.last(route), App.warehouse);
  };

  return solution.map(route => routeCost(route))
    .reduce((a, b) => a + b, 0);
}

function bestSolution(population) {
  return population.reduce(function(prev, cur) {
    // Sometimes we might get empty solutions!
    if (!cur.length) {
      return prev;
    }

    var cost = solutionCost(cur);
    if (solutionCost(cur) < prev.cost) {
      return { solution: cur, cost: cost };
    }
    return prev;
  }, { solution: [], cost: Infinity });
}

function findRoute(requests, fleetSize) {
  const initial = initialPopulation(requests);
  return iterate(initial, bestSolution(initial).cost);
}

